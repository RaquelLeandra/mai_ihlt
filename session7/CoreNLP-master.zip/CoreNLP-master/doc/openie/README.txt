Stanford Open Domain Relation Extractor, v3.5.2 - 2015-04-20
Copyright (c) 2002-2012 The Board of Trustees of
The Leland Stanford Junior University. All Rights Reserved.

Original author: Gabor Angeli
Code contributions:

This package contains an open domain relation extractor, producing
<subject, relation, object> triples where each element can be an arbitrary
plain-text element.
